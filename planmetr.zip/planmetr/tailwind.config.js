/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,jsx}", "./components/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        bg: "#14171b",
        panel: "#1d2228",
        panel2: "#232a31",
        line: "#2e363f",
        dim: "#8b97a3",
        laser: "#ff4438",
        wood: "#d9a05b",
      },
      fontFamily: {
        sans: ["Archivo", "system-ui", "sans-serif"],
        mono: ["'JetBrains Mono'", "monospace"],
      },
    },
  },
  plugins: [],
};
