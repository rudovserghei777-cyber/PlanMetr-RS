import "./globals.css";

export const metadata = {
  title: "ПЛАНМЕТР — обмер, материалы, смета",
  description:
    "Планировщик помещений для мастера по полам: обмер комнат, расчёт материалов с запасом, плинтус с вычетом проёмов и готовая смета.",
  manifest: "/manifest.json",
  appleWebApp: { capable: true, statusBarStyle: "black-translucent", title: "ПЛАНМЕТР" },
  icons: { apple: "/icon-192.png" },
};

export const viewport = {
  themeColor: "#14171b",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({ children }) {
  return (
    <html lang="ru">
      <body>{children}</body>
    </html>
  );
}
