"use client";
import { useState, useRef, useEffect, useMemo, useCallback } from "react";

/* ════════════════════════════════════════════════════════════
   ПЛАНМЕТР — Next.js версия
   Логика переходов (как в MeasureOn): Проекты → Обмер → Материалы → Смета
   «Назад» на каждом шаге сохраняет состояние. Undo/Redo при обмере.
   ════════════════════════════════════════════════════════════ */

const SNAP = 0.05;
const LS_KEY = "planmetr.projects.v1";
const uid = () => Math.random().toString(36).slice(2, 9);

function polyArea(pts) {
  if (!pts || pts.length < 3) return 0;
  let s = 0;
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i], b = pts[(i + 1) % pts.length];
    s += a.x * b.y - b.x * a.y;
  }
  return Math.abs(s) / 2;
}
function polyPerimeter(pts) {
  if (!pts || pts.length < 2) return 0;
  let p = 0;
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i], b = pts[(i + 1) % pts.length];
    p += Math.hypot(b.x - a.x, b.y - a.y);
  }
  return p;
}
const fm = (n, d = 2) =>
  (Math.round(n * 10 ** d) / 10 ** d).toLocaleString("ru-RU", { maximumFractionDigits: d });

const COVERINGS = {
  vinyl: { label: "Клик-винил", price: 28, pack: 2.2, underlay: true, glue: false },
  laminate: { label: "Ламинат", price: 16, pack: 2.4, underlay: true, glue: false },
  parquet: { label: "Паркетная доска", price: 55, pack: 2.0, underlay: true, glue: false },
  glued: { label: "Паркет на клей", price: 75, pack: 1.8, underlay: false, glue: true },
};

const DEFAULT_SETTINGS = {
  covering: "vinyl", price: 28, pack: 2.2, waste: 7,
  underlayPrice: 3, plinthPrice: 6, glueRate: 1.2, gluePrice: 8, workPrice: 25,
};

const newProject = (n) => ({
  id: uid(),
  name: `Объект ${n}`,
  createdAt: Date.now(),
  rooms: [],
  settings: { ...DEFAULT_SETTINGS },
});

/* ── shadcn-стиль примитивы ── */
const Btn = ({ variant = "default", size = "md", className = "", ...p }) => (
  <button
    className={
      "inline-flex items-center justify-center gap-2 rounded-lg font-semibold transition-colors disabled:opacity-40 disabled:pointer-events-none " +
      (size === "sm" ? "px-2.5 py-1.5 text-xs " : "px-3.5 py-2 text-sm ") +
      (variant === "default"
        ? "bg-panel2 border border-line hover:border-dim "
        : variant === "primary"
        ? "bg-laser text-white hover:bg-[#e23a2f] "
        : variant === "wood"
        ? "bg-wood text-[#241a0e] hover:bg-[#c8924f] "
        : "bg-transparent text-dim hover:text-white ") +
      className
    }
    {...p}
  />
);
const Card = ({ className = "", ...p }) => (
  <div className={"bg-panel border border-line rounded-xl p-4 " + className} {...p} />
);
const H3 = ({ children }) => (
  <h3 className="text-[11px] tracking-[1.4px] uppercase text-dim font-bold mb-3">{children}</h3>
);
const Input = ({ className = "", ...p }) => (
  <input
    className={"bg-bg border border-line rounded-lg px-2.5 py-2 font-mono text-[13px] outline-none focus:border-wood w-20 " + className}
    {...p}
  />
);

const STEPS = [
  { id: "measure", label: "1 · Обмер" },
  { id: "materials", label: "2 · Материалы" },
  { id: "estimate", label: "3 · Смета" },
];

export default function Planner() {
  const [projects, setProjects] = useState([]);
  const [currentId, setCurrentId] = useState(null);
  const [step, setStep] = useState("projects"); // projects | measure | materials | estimate
  const [loaded, setLoaded] = useState(false);
  const [toast, setToast] = useState("");

  /* рисование */
  const [draft, setDraft] = useState(null);
  const [hover, setHover] = useState(null);
  const [scale, setScale] = useState(60);
  const [activeRoomId, setActiveRoomId] = useState(null);
  const [rectW, setRectW] = useState("4");
  const [rectL, setRectL] = useState("5");
  const svgRef = useRef(null);

  /* undo / redo для обмера */
  const histRef = useRef([]);
  const redoRef = useRef([]);
  const [, force] = useState(0);

  /* ── загрузка / автосохранение localStorage ── */
  useEffect(() => {
    try {
      const raw = localStorage.getItem(LS_KEY);
      if (raw) setProjects(JSON.parse(raw));
    } catch {}
    setLoaded(true);
  }, []);
  useEffect(() => {
    if (!loaded) return;
    try { localStorage.setItem(LS_KEY, JSON.stringify(projects)); } catch {}
  }, [projects, loaded]);

  const notify = (m) => { setToast(m); setTimeout(() => setToast(""), 2400); };

  const project = projects.find((p) => p.id === currentId) || null;
  const rooms = project?.rooms || [];
  const settings = project?.settings || DEFAULT_SETTINGS;

  const patchProject = useCallback(
    (patch) => setProjects((ps) => ps.map((p) => (p.id === currentId ? { ...p, ...patch } : p))),
    [currentId]
  );

  /* история: снимок перед каждым изменением комнат */
  const setRoomsWithHistory = (next) => {
    histRef.current = [...histRef.current.slice(-49), rooms];
    redoRef.current = [];
    patchProject({ rooms: next });
  };
  const undo = () => {
    if (!histRef.current.length) return;
    const prev = histRef.current.pop();
    redoRef.current.push(rooms);
    patchProject({ rooms: prev });
    force((x) => x + 1);
    notify("Шаг назад ↶");
  };
  const redo = () => {
    if (!redoRef.current.length) return;
    const next = redoRef.current.pop();
    histRef.current.push(rooms);
    patchProject({ rooms: next });
    force((x) => x + 1);
    notify("Шаг вперёд ↷");
  };

  /* ── навигация (логика переходов) ── */
  const openProject = (id) => {
    setCurrentId(id);
    histRef.current = []; redoRef.current = [];
    setActiveRoomId(null); setDraft(null);
    setStep("measure");
  };
  const goBack = () => {
    if (step === "measure") { setStep("projects"); setCurrentId(null); setDraft(null); }
    else if (step === "materials") setStep("measure");
    else if (step === "estimate") setStep("materials");
  };
  const goNext = () => {
    if (step === "measure") {
      if (!rooms.length) { notify("Сначала добавь хотя бы одну комнату"); return; }
      setStep("materials");
    } else if (step === "materials") setStep("estimate");
  };

  /* ── координаты и рисование ── */
  const toMeters = (e) => {
    const r = svgRef.current.getBoundingClientRect();
    const x = (e.clientX - r.left) / scale;
    const y = (e.clientY - r.top) / scale;
    return { x: Math.round(x / SNAP) * SNAP, y: Math.round(y / SNAP) * SNAP };
  };
  const onCanvasClick = (e) => {
    const p = toMeters(e);
    if (draft === null) { setDraft([p]); setActiveRoomId(null); return; }
    if (draft.length >= 3 && Math.hypot(p.x - draft[0].x, p.y - draft[0].y) < 0.25) { finishDraft(); return; }
    setDraft([...draft, p]);
  };
  const finishDraft = () => {
    if (!draft || draft.length < 3) { setDraft(null); return; }
    const room = { id: uid(), name: `Комната ${rooms.length + 1}`, points: draft, doors: [] };
    setRoomsWithHistory([...rooms, room]);
    setActiveRoomId(room.id);
    setDraft(null);
    notify(`Добавлена: ${room.name} — ${fm(polyArea(draft))} м²`);
  };
  const undoDraftPoint = () => {
    if (!draft) return;
    draft.length <= 1 ? setDraft(null) : setDraft(draft.slice(0, -1));
  };
  const addRect = () => {
    const w = parseFloat(String(rectW).replace(",", "."));
    const l = parseFloat(String(rectL).replace(",", "."));
    if (!w || !l || w <= 0 || l <= 0) { notify("Введи корректные размеры"); return; }
    let ox = 0.5;
    rooms.forEach((r) => r.points.forEach((p) => { ox = Math.max(ox, p.x + 0.5); }));
    const pts = [{ x: ox, y: 0.5 }, { x: ox + w, y: 0.5 }, { x: ox + w, y: 0.5 + l }, { x: ox, y: 0.5 + l }];
    const room = { id: uid(), name: `Комната ${rooms.length + 1}`, points: pts, doors: [] };
    setRoomsWithHistory([...rooms, room]);
    setActiveRoomId(room.id);
    notify(`Прямоугольник ${fm(w)}×${fm(l)} м — ${fm(w * l)} м²`);
  };
  const deleteRoom = (id) => {
    setRoomsWithHistory(rooms.filter((r) => r.id !== id));
    if (activeRoomId === id) setActiveRoomId(null);
  };
  const updateRoom = (id, patch) =>
    setRoomsWithHistory(rooms.map((r) => (r.id === id ? { ...r, ...patch } : r)));
  const renameRoomLive = (id, name) =>
    patchProject({ rooms: rooms.map((r) => (r.id === id ? { ...r, name } : r)) }); // без записи в историю на каждый символ

  const activeRoom = rooms.find((r) => r.id === activeRoomId) || null;

  /* ── расчёты ── */
  const totals = useMemo(() => {
    const S = settings;
    const area = rooms.reduce((s, r) => s + polyArea(r.points), 0);
    const perimeter = rooms.reduce((s, r) => s + polyPerimeter(r.points), 0);
    const doorsW = rooms.reduce((s, r) => s + (r.doors || []).reduce((a, d) => a + (parseFloat(d.width) || 0), 0), 0);
    const cov = COVERINGS[S.covering];
    const areaWaste = area * (1 + S.waste / 100);
    const packs = S.pack > 0 ? Math.ceil(areaWaste / S.pack) : 0;
    const matArea = packs * S.pack;
    const plinth = Math.max(0, perimeter - doorsW) * 1.1;
    const lines = [];
    if (area > 0) {
      lines.push({ name: `${cov.label} — ${packs} уп. × ${fm(S.pack)} м²`, qty: `${fm(matArea)} м²`, cost: matArea * S.price });
      if (cov.underlay) lines.push({ name: "Подложка", qty: `${fm(areaWaste)} м²`, cost: areaWaste * S.underlayPrice });
      if (cov.glue) {
        const kg = area * S.glueRate;
        lines.push({ name: "Клей", qty: `${fm(kg, 1)} кг`, cost: kg * S.gluePrice });
      }
      lines.push({ name: "Плинтус (минус проёмы, +10% стыки)", qty: `${fm(plinth)} м.п.`, cost: plinth * S.plinthPrice });
      lines.push({ name: "Работа: укладка", qty: `${fm(area)} м²`, cost: area * S.workPrice });
    }
    const total = lines.reduce((s, l) => s + l.cost, 0);
    return { area, perimeter, doorsW, packs, matArea, plinth, lines, total, areaWaste };
  }, [rooms, settings]);

  /* ── холст ── */
  const allPts = [...rooms.flatMap((r) => r.points), ...(draft || [])];
  const maxX = Math.max(12, ...allPts.map((p) => p.x + 2));
  const maxY = Math.max(9, ...allPts.map((p) => p.y + 2));
  const W = maxX * scale, H = maxY * scale;

  const wallLabels = (pts) => {
    const out = [];
    for (let i = 0; i < pts.length; i++) {
      const a = pts[i], b = pts[(i + 1) % pts.length];
      const len = Math.hypot(b.x - a.x, b.y - a.y);
      if (len < 0.15) continue;
      out.push({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, len });
    }
    return out;
  };

  const S = settings;
  const setS = (patch) => patchProject({ settings: { ...S, ...patch } });
  const pickCovering = (k) => setS({ covering: k, price: COVERINGS[k].price, pack: COVERINGS[k].pack });

  if (!loaded) return null;

  /* ════════ ЭКРАН: ПРОЕКТЫ ════════ */
  if (step === "projects") {
    return (
      <div className="min-h-screen font-sans">
        <Header />
        <div className="max-w-2xl mx-auto p-5 flex flex-col gap-4">
          <Card>
            <H3>Мои объекты · {projects.length}</H3>
            {projects.length === 0 && (
              <p className="text-dim text-sm">Пока нет объектов. Создай первый — и вперёд на обмер.</p>
            )}
            <div className="flex flex-col gap-2">
              {projects.map((p) => (
                <div key={p.id}
                  className="flex items-center gap-3 p-3 rounded-lg border border-line hover:border-wood cursor-pointer"
                  onClick={() => openProject(p.id)}>
                  <div className="flex-1">
                    <div className="font-bold">{p.name}</div>
                    <div className="text-dim text-xs mt-0.5">
                      {p.rooms.length} комн. · {fm(p.rooms.reduce((s, r) => s + polyArea(r.points), 0))} м² ·{" "}
                      {new Date(p.createdAt).toLocaleDateString("ru-RU")}
                    </div>
                  </div>
                  <Btn size="sm" variant="ghost"
                    onClick={(e) => { e.stopPropagation(); setProjects(projects.filter((x) => x.id !== p.id)); }}>✕</Btn>
                </div>
              ))}
            </div>
            <Btn variant="primary" className="mt-4 w-full"
              onClick={() => { const p = newProject(projects.length + 1); setProjects([...projects, p]); openProject(p.id); }}>
              + Новый объект
            </Btn>
          </Card>
          <p className="text-dim text-xs leading-relaxed">
            Данные хранятся локально на этом устройстве (localStorage) и не пропадают между сессиями.
          </p>
        </div>
        {toast && <Toast>{toast}</Toast>}
      </div>
    );
  }

  /* ════════ ЭКРАНЫ ШАГОВ ════════ */
  return (
    <div className="min-h-screen font-sans flex flex-col">
      <Header>
        <div className="no-print flex items-center gap-2 flex-wrap">
          <Btn size="sm" onClick={goBack}>← Назад</Btn>
          <div className="flex gap-1 bg-panel border border-line rounded-lg p-1">
            {STEPS.map((s) => (
              <button key={s.id} onClick={() => (s.id === "measure" || rooms.length) && setStep(s.id)}
                className={"px-3 py-1.5 rounded-md text-xs font-bold " + (step === s.id ? "bg-panel2 text-white" : "text-dim hover:text-white")}>
                {s.label}
              </button>
            ))}
          </div>
          <span className="text-dim text-xs font-bold truncate max-w-[140px]">{project?.name}</span>
          {step !== "estimate" && <Btn size="sm" variant="primary" onClick={goNext}>Далее →</Btn>}
        </div>
      </Header>

      {/* ── ШАГ 1: ОБМЕР ── */}
      {step === "measure" && (
        <div className="flex flex-1 min-h-0 flex-wrap">
          <div className="w-full md:w-[330px] md:border-r border-b md:border-b-0 border-line p-4 flex flex-col gap-4 overflow-y-auto md:max-h-[calc(100vh-61px)]">
            <Card>
              <H3>Быстрый прямоугольник</H3>
              <div className="flex gap-2 flex-wrap">
                <label className="flex flex-col gap-1 text-xs text-dim flex-1">Ширина, м
                  <Input value={rectW} onChange={(e) => setRectW(e.target.value)} inputMode="decimal" /></label>
                <label className="flex flex-col gap-1 text-xs text-dim flex-1">Длина, м
                  <Input value={rectL} onChange={(e) => setRectL(e.target.value)} inputMode="decimal" /></label>
              </div>
              <Btn variant="primary" className="mt-3 w-full" onClick={addRect}>+ Добавить комнату</Btn>
              <p className="text-dim text-xs mt-2 leading-relaxed">
                Сложная форма (Г-образная, ниши) — кликай по сетке. Замкни контур кликом по первой точке.
              </p>
            </Card>

            <Card>
              <H3>Редактирование</H3>
              <div className="flex gap-2">
                <Btn size="sm" onClick={undo} disabled={!histRef.current.length}>↶ Отменить</Btn>
                <Btn size="sm" onClick={redo} disabled={!redoRef.current.length}>↷ Вернуть</Btn>
              </div>
              <p className="text-dim text-xs mt-2">Каждое действие на плане можно откатить на предыдущий шаг.</p>
            </Card>

            {draft && (
              <Card className="border-laser">
                <H3>Рисуем контур · {draft.length} тчк</H3>
                <div className="flex gap-2 flex-wrap">
                  <Btn size="sm" onClick={undoDraftPoint}>← Точку назад</Btn>
                  <Btn size="sm" variant="primary" onClick={finishDraft} disabled={draft.length < 3}>Замкнуть</Btn>
                  <Btn size="sm" variant="ghost" onClick={() => setDraft(null)}>✕</Btn>
                </div>
              </Card>
            )}

            <Card>
              <H3>Комнаты · {rooms.length}</H3>
              {rooms.length === 0 && <p className="text-dim text-sm">Добавь прямоугольник или нарисуй контур.</p>}
              <div className="flex flex-col gap-1">
                {rooms.map((r) => (
                  <div key={r.id}
                    className={"flex items-center gap-2 px-2.5 py-2 rounded-lg cursor-pointer border " +
                      (r.id === activeRoomId ? "border-laser bg-panel2" : "border-transparent hover:bg-panel2")}
                    onClick={() => setActiveRoomId(r.id)}>
                    <span className="flex-1 font-semibold text-sm">{r.name}</span>
                    <span className="text-wood font-mono text-[13px]">{fm(polyArea(r.points))} м²</span>
                    <button className="text-dim hover:text-laser px-1.5"
                      onClick={(e) => { e.stopPropagation(); deleteRoom(r.id); }}>✕</button>
                  </div>
                ))}
              </div>
            </Card>

            {activeRoom && (
              <Card>
                <H3>{activeRoom.name}</H3>
                <Input className="w-full font-sans mb-3" value={activeRoom.name}
                  onChange={(e) => renameRoomLive(activeRoom.id, e.target.value)} />
                <Stat label="Площадь" value={`${fm(polyArea(activeRoom.points))} м²`} />
                <Stat label="Периметр" value={`${fm(polyPerimeter(activeRoom.points))} м`} />
                <div className="mt-3">
                  <div className="text-xs text-dim mb-1.5">Проёмы (двери) — вычитаются из плинтуса</div>
                  {(activeRoom.doors || []).map((d) => (
                    <div className="flex items-center gap-2 mt-1.5" key={d.id}>
                      <Input value={d.width} inputMode="decimal"
                        onChange={(e) => updateRoom(activeRoom.id, {
                          doors: activeRoom.doors.map((x) => x.id === d.id ? { ...x, width: e.target.value } : x),
                        })} />
                      <span className="text-xs text-dim">м</span>
                      <button className="text-dim hover:text-laser px-1.5"
                        onClick={() => updateRoom(activeRoom.id, { doors: activeRoom.doors.filter((x) => x.id !== d.id) })}>✕</button>
                    </div>
                  ))}
                  <Btn size="sm" className="mt-2"
                    onClick={() => updateRoom(activeRoom.id, { doors: [...(activeRoom.doors || []), { id: uid(), width: 0.9 }] })}>
                    + Проём 0,90 м
                  </Btn>
                </div>
              </Card>
            )}

            <TotalsCard totals={totals} waste={S.waste} />
          </div>

          {/* холст */}
          <div className="flex-1 min-w-[300px] overflow-auto relative md:max-h-[calc(100vh-61px)]">
            <div className="absolute top-3 right-3.5 flex gap-1.5 z-10">
              <Btn size="sm" onClick={() => setScale((s) => Math.min(140, s + 15))}>＋</Btn>
              <Btn size="sm" onClick={() => setScale((s) => Math.max(25, s - 15))}>－</Btn>
            </div>
            <svg ref={svgRef} width={W} height={H} className="block cursor-crosshair"
              onClick={onCanvasClick}
              onMouseMove={(e) => setHover(toMeters(e))}
              onMouseLeave={() => setHover(null)}>
              <defs>
                <pattern id="g1" width={scale * 0.5} height={scale * 0.5} patternUnits="userSpaceOnUse">
                  <path d={`M ${scale * 0.5} 0 L 0 0 0 ${scale * 0.5}`} fill="none" stroke="#222a33" strokeWidth="1" />
                </pattern>
                <pattern id="g2" width={scale} height={scale} patternUnits="userSpaceOnUse">
                  <rect width={scale} height={scale} fill="url(#g1)" />
                  <path d={`M ${scale} 0 L 0 0 0 ${scale}`} fill="none" stroke="#2d3845" strokeWidth="1.2" />
                </pattern>
              </defs>
              <rect width={W} height={H} fill="url(#g2)" />

              {rooms.map((r) => {
                const on = r.id === activeRoomId;
                const d = r.points.map((p, i) => `${i ? "L" : "M"}${p.x * scale},${p.y * scale}`).join(" ") + " Z";
                const c = r.points.reduce((a, p) => ({ x: a.x + p.x / r.points.length, y: a.y + p.y / r.points.length }), { x: 0, y: 0 });
                return (
                  <g key={r.id} className="cursor-pointer"
                    onClick={(e) => { if (!draft) { e.stopPropagation(); setActiveRoomId(r.id); } }}>
                    <path d={d} fill={on ? "rgba(217,160,91,.16)" : "rgba(217,160,91,.07)"}
                      stroke={on ? "#d9a05b" : "#6f6253"} strokeWidth={on ? 2.5 : 1.6} strokeLinejoin="round" />
                    {wallLabels(r.points).map((w, i) => (
                      <text key={i} x={w.x * scale} y={w.y * scale - 5} textAnchor="middle" fontSize="11.5"
                        fill={on ? "#ff5b50" : "#9aa6b2"} fontFamily="'JetBrains Mono',monospace" fontWeight="600"
                        style={{ paintOrder: "stroke", stroke: "#14171b", strokeWidth: 3 }}>{fm(w.len)}</text>
                    ))}
                    <text x={c.x * scale} y={c.y * scale} textAnchor="middle" fontSize="13" fill="#e9edf1" fontWeight="700"
                      style={{ paintOrder: "stroke", stroke: "#14171b", strokeWidth: 4 }}>{r.name}</text>
                    <text x={c.x * scale} y={c.y * scale + 17} textAnchor="middle" fontSize="12" fill="#d9a05b"
                      fontFamily="'JetBrains Mono',monospace"
                      style={{ paintOrder: "stroke", stroke: "#14171b", strokeWidth: 3 }}>{fm(polyArea(r.points))} м²</text>
                  </g>
                );
              })}

              {draft && (
                <g>
                  {draft.length > 1 && (
                    <path d={draft.map((p, i) => `${i ? "L" : "M"}${p.x * scale},${p.y * scale}`).join(" ")}
                      fill="none" stroke="#ff4438" strokeWidth="2" strokeDasharray="6 4" />
                  )}
                  {hover && draft.length > 0 && (
                    <>
                      <line x1={draft[draft.length - 1].x * scale} y1={draft[draft.length - 1].y * scale}
                        x2={hover.x * scale} y2={hover.y * scale} stroke="#ff4438" strokeWidth="1.4" strokeDasharray="3 4" opacity=".7" />
                      <text x={((draft[draft.length - 1].x + hover.x) / 2) * scale}
                        y={((draft[draft.length - 1].y + hover.y) / 2) * scale - 6}
                        textAnchor="middle" fontSize="11.5" fill="#ff5b50" fontFamily="'JetBrains Mono',monospace" fontWeight="600"
                        style={{ paintOrder: "stroke", stroke: "#14171b", strokeWidth: 3 }}>
                        {fm(Math.hypot(hover.x - draft[draft.length - 1].x, hover.y - draft[draft.length - 1].y))} м
                      </text>
                    </>
                  )}
                  {draft.map((p, i) => (
                    <circle key={i} cx={p.x * scale} cy={p.y * scale} r={i === 0 ? 6 : 4}
                      fill={i === 0 ? "#ff4438" : "#14171b"} stroke="#ff4438" strokeWidth="2" />
                  ))}
                </g>
              )}

              {hover && (
                <g pointerEvents="none" opacity=".55">
                  <line x1={hover.x * scale - 9} y1={hover.y * scale} x2={hover.x * scale + 9} y2={hover.y * scale} stroke="#ff4438" strokeWidth="1.2" />
                  <line x1={hover.x * scale} y1={hover.y * scale - 9} x2={hover.x * scale} y2={hover.y * scale + 9} stroke="#ff4438" strokeWidth="1.2" />
                </g>
              )}
            </svg>
          </div>
        </div>
      )}

      {/* ── ШАГ 2: МАТЕРИАЛЫ ── */}
      {step === "materials" && (
        <div className="max-w-2xl mx-auto p-5 w-full flex flex-col gap-4">
          <Card>
            <H3>Покрытие</H3>
            <div className="grid grid-cols-2 gap-2">
              {Object.entries(COVERINGS).map(([k, c]) => (
                <button key={k} onClick={() => pickCovering(k)}
                  className={"border rounded-lg p-2.5 text-left text-[13px] font-semibold " +
                    (S.covering === k ? "border-wood text-wood" : "border-line hover:border-dim")}>
                  {c.label}
                  <span className="block text-dim text-xs font-normal mt-0.5">≈ {c.price} €/м²</span>
                </button>
              ))}
            </div>
            <div className="flex gap-2 mt-4 flex-wrap">
              <Lbl t="Цена, €/м²"><Input value={S.price} inputMode="decimal" onChange={(e) => setS({ price: parseFloat(e.target.value) || 0 })} /></Lbl>
              <Lbl t="Пачка, м²"><Input value={S.pack} inputMode="decimal" onChange={(e) => setS({ pack: parseFloat(e.target.value) || 0 })} /></Lbl>
              <Lbl t="Запас, %"><Input value={S.waste} inputMode="decimal" onChange={(e) => setS({ waste: parseFloat(e.target.value) || 0 })} /></Lbl>
            </div>
          </Card>
          <Card>
            <H3>Подложка · плинтус · работа</H3>
            <div className="flex gap-2 flex-wrap">
              <Lbl t="Подложка €/м²"><Input value={S.underlayPrice} inputMode="decimal" onChange={(e) => setS({ underlayPrice: parseFloat(e.target.value) || 0 })} /></Lbl>
              <Lbl t="Плинтус €/м.п."><Input value={S.plinthPrice} inputMode="decimal" onChange={(e) => setS({ plinthPrice: parseFloat(e.target.value) || 0 })} /></Lbl>
              <Lbl t="Работа €/м²"><Input value={S.workPrice} inputMode="decimal" onChange={(e) => setS({ workPrice: parseFloat(e.target.value) || 0 })} /></Lbl>
            </div>
            {COVERINGS[S.covering].glue && (
              <div className="flex gap-2 mt-3 flex-wrap">
                <Lbl t="Клей кг/м²"><Input value={S.glueRate} inputMode="decimal" onChange={(e) => setS({ glueRate: parseFloat(e.target.value) || 0 })} /></Lbl>
                <Lbl t="Клей €/кг"><Input value={S.gluePrice} inputMode="decimal" onChange={(e) => setS({ gluePrice: parseFloat(e.target.value) || 0 })} /></Lbl>
              </div>
            )}
          </Card>
          <TotalsCard totals={totals} waste={S.waste} />
          <Btn variant="primary" className="w-full" onClick={goNext}>Сформировать смету →</Btn>
        </div>
      )}

      {/* ── ШАГ 3: СМЕТА ── */}
      {step === "estimate" && (
        <div className="max-w-2xl mx-auto p-5 w-full flex flex-col gap-4 print-area">
          <Card>
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div>
                <div className="font-extrabold text-lg">{project?.name} — смета</div>
                <div className="text-dim text-xs">{new Date().toLocaleDateString("ru-RU")} · {rooms.length} комн. · {fm(totals.area)} м²</div>
              </div>
              <Btn className="no-print" onClick={() => window.print()}>🖨 Печать / PDF</Btn>
            </div>
            <table className="w-full text-sm mt-4 border-collapse">
              <tbody>
                {rooms.map((r) => (
                  <tr key={r.id} className="border-b border-line border-dashed text-dim">
                    <td className="py-1.5">{r.name}</td>
                    <td className="py-1.5 text-right font-mono">{fm(polyArea(r.points))} м² · {fm(polyPerimeter(r.points))} м</td>
                  </tr>
                ))}
                {totals.lines.map((l, i) => (
                  <tr key={i} className="border-b border-line">
                    <td className="py-2">{l.name}<br /><span className="text-dim text-xs">{l.qty}</span></td>
                    <td className="py-2 text-right font-mono whitespace-nowrap">{fm(l.cost)} €</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="flex justify-between items-center mt-4 p-3.5 rounded-xl border border-wood bg-gradient-to-br from-[#2a2017] to-panel">
              <span className="font-bold">ИТОГО</span>
              <span className="font-mono text-xl text-wood font-semibold">{fm(totals.total)} €</span>
            </div>
          </Card>
          <p className="text-dim text-xs no-print">
            «Печать / PDF» — в диалоге печати выбери «Сохранить как PDF», и смету можно отправить клиенту.
          </p>
        </div>
      )}

      {toast && <Toast>{toast}</Toast>}
    </div>
  );
}

/* ── мелкие компоненты ── */
const Header = ({ children }) => (
  <header className="no-print flex items-center gap-4 px-4 py-3 border-b border-line flex-wrap">
    <div className="font-extrabold text-lg tracking-wide">
      ПЛАН<span className="text-laser">МЕТР</span>{" "}
      <span className="text-dim text-xs font-medium">обмер · материалы · смета</span>
    </div>
    <div className="flex-1" />
    {children}
  </header>
);
const Stat = ({ label, value }) => (
  <div className="flex justify-between text-[13px] py-1.5 border-b border-dashed border-line last:border-0">
    <span>{label}</span><b className="font-mono font-semibold">{value}</b>
  </div>
);
const Lbl = ({ t, children }) => (
  <label className="flex flex-col gap-1 text-xs text-dim flex-1 min-w-[88px]">{t}{children}</label>
);
const Toast = ({ children }) => (
  <div className="fixed bottom-5 left-1/2 -translate-x-1/2 bg-panel2 border border-line px-4.5 py-2.5 px-5 rounded-xl text-sm z-50 shadow-2xl">{children}</div>
);
const TotalsCard = ({ totals, waste }) => (
  <div className="bg-panel border border-line rounded-xl p-4">
    <h3 className="text-[11px] tracking-[1.4px] uppercase text-dim font-bold mb-3">Итого по объекту</h3>
    <Stat label="Площадь" value={`${fm(totals.area)} м²`} />
    <Stat label={`С запасом ${waste}%`} value={`${fm(totals.areaWaste)} м²`} />
    <Stat label="Пачек" value={String(totals.packs)} />
    <Stat label="Плинтус" value={`${fm(totals.plinth)} м.п.`} />
    <div className="flex justify-between items-center mt-3 pt-3 border-t border-line">
      <span className="font-bold text-sm">СМЕТА</span>
      <span className="font-mono text-lg text-wood font-semibold">{fm(totals.total)} €</span>
    </div>
  </div>
);
